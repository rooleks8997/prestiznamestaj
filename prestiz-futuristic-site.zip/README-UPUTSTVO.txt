# Prestiž futuristic site

Zameni postojeće fajlove u GitHub repozitorijumu ovim fajlovima:
- index.html
- style.css
- script.js

VAŽNO:
1. U `index.html` zameni `+381600000000` svojim pravim brojem telefona.
2. Zameni `https://wa.me/381600000000` svojim WhatsApp brojem.
3. Zameni Instagram link pravim linkom profila.
4. Folder `images` ostaje isti kao na postojećem sajtu.
